This directory should contains 4 files, due to the file size limitation of GitHub, I have put these model files in [dropbox](https://www.dropbox.com/s/wp6wmn7nmli5e0f/Model.zip?dl=0) 
to download separately.

`alexRainApr06.tfl`: trained model for AlexNet, required for raindrop detection.

`alexRaindropApr12.tfl` (3 files): trained model for AlexNet, required for raindrop classification.

